import json
import random
import re
from datetime import datetime

with open("data.json", "r", encoding="utf-8") as file:
    data = json.load(file)

name = data['name']
greetings = data['greetings']
quizzes = data['quizzes']

def perform_math(expression):
    try:
        # Evaluate the math expression from the user's input
        result = eval(expression)
        return result
    except Exception as e:
        return "Sorry, I couldn't process that math operation."

while True:
    user = input("User: ").lower().strip("!?,.")
    
    if "prompts" in user:
        pass
    elif "what" in user and "your" in user and "name" in user:
        print("Chatbot:", random.choice(name))
    elif "hello" in user or "hey" in user or "hi" in user:
        print("Chatbot:", random.choice(greetings))
    elif "time" in user in user:
        current_time = datetime.now().strftime("%H:%M")
        print("Chatbot: The current time is", current_time)
    elif "quiz" in user:
        quiz = random.choice(quizzes)
        print("Chatbot: " + quiz['question'])
        user_answer = input("Your answer: ").strip().lower()
    
        if user_answer == quiz['answer'].lower():
            print("Chatbot: Correct!")
        else:
            print("Chatbot: Incorrect. The correct answer is:", quiz['answer'])
    
    elif "calculate" in user or "math" in user:
        # Extract math expressions using regular expressions
        math_expression = re.findall(r'[-+*/0-9(). ]+', user)
        
        if math_expression:
            expression = math_expression[0].strip()
            result = perform_math(expression)
            print(f"Chatbot: The result of {expression} is {result}.")
        else:
            print("Chatbot: Sorry, I couldn't understand the math expression.")
    
    else:
        print("Chatbot: Sorry I didn't get that.")